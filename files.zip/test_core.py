"""Tests for the parts that can be wrong silently.

Everything here runs without a network. The API client's signing is tested
against a known key; its endpoints are not, because a test that mocks the
exchange only proves the mock works.
"""
import math
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from bot.fees import fee_per_contract_cents, maker_fee_cents, taker_fee_cents
from bot.pricer import digital_fair_value, implied_sigma_per_sec, norm_cdf
from bot.risk import Block, OrderIntent, PortfolioState, RiskGate
from bot.strategy import Book, BookSide, evaluate
from bot.vol import EwmaVar, SpotState, halflife_to_lambda


# ---------------------------------------------------------------- fees
def test_taker_fee_peaks_at_fifty():
    at50 = taker_fee_cents(50, 1)
    assert at50 == 2  # ceil(1.75c)
    assert taker_fee_cents(80, 1) <= at50
    assert taker_fee_cents(20, 1) <= at50
    assert taker_fee_cents(5, 1) < taker_fee_cents(20, 1)


def test_fee_symmetric_around_fifty():
    for p in (10, 25, 40):
        assert taker_fee_cents(p, 100) == taker_fee_cents(100-p, 100)


def test_fee_scales_with_contracts():
    assert taker_fee_cents(50, 100) == 175
    assert taker_fee_cents(50, 0) == 0


def test_maker_ratio_zero_means_free():
    assert maker_fee_cents(50, 100, maker_ratio=0.0) == 0
    assert maker_fee_cents(50, 100, maker_ratio=0.25) == 44


def test_per_contract_fee_unrounded():
    # 0.07 * 0.5 * 0.5 * 100 = 1.75c exactly
    assert fee_per_contract_cents(50, False) == pytest.approx(1.75)
    assert fee_per_contract_cents(50, True, maker_ratio=0.25) == pytest.approx(0.4375)


# ---------------------------------------------------------------- pricer
def test_norm_cdf_known_values():
    assert norm_cdf(0.0) == pytest.approx(0.5)
    assert norm_cdf(1.96) == pytest.approx(0.975, abs=1e-3)
    assert norm_cdf(-1.96) == pytest.approx(0.025, abs=1e-3)


def test_at_the_money_is_near_half():
    fv = digital_fair_value(100_000, 100_000, 900, 4.8e-5)
    assert fv.prob_yes == pytest.approx(0.5, abs=0.01)


def test_deep_itm_and_otm():
    assert digital_fair_value(110_000, 100_000, 900, 4.8e-5).prob_yes > 0.999
    assert digital_fair_value(90_000, 100_000, 900, 4.8e-5).prob_yes < 0.001


def test_time_decay_sharpens_the_digital():
    """Same distance from strike, less time -> more certain."""
    far = digital_fair_value(100_050, 100_000, 900, 4.8e-5).prob_yes
    near = digital_fair_value(100_050, 100_000, 60, 4.8e-5).prob_yes
    assert near > far


def test_zero_time_is_degenerate():
    fv = digital_fair_value(100_001, 100_000, 0, 4.8e-5)
    assert fv.degenerate and fv.prob_yes == 1.0
    fv = digital_fair_value(99_999, 100_000, 0, 4.8e-5)
    assert fv.degenerate and fv.prob_yes == 0.0


def test_yes_and_no_sum_to_one():
    fv = digital_fair_value(100_123, 100_000, 450, 4.8e-5)
    assert fv.yes_cents + fv.no_cents == pytest.approx(100.0)


def test_higher_vol_pulls_toward_half():
    low = digital_fair_value(100_200, 100_000, 900, 2e-5).prob_yes
    high = digital_fair_value(100_200, 100_000, 900, 2e-4).prob_yes
    assert abs(high - 0.5) < abs(low - 0.5)


def test_implied_vol_roundtrip():
    sigma = 5.0e-5
    fv = digital_fair_value(100_050, 100_000, 600, sigma)
    back = implied_sigma_per_sec(fv.yes_cents, 100_050, 100_000, 600)
    assert back == pytest.approx(sigma, rel=1e-3)


def test_pricer_rejects_bad_input():
    with pytest.raises(ValueError):
        digital_fair_value(0, 100, 900, 1e-5)
    with pytest.raises(ValueError):
        digital_fair_value(100, 100, 900, -1)


# ---------------------------------------------------------------- vol
def test_halflife_lambda():
    lam = halflife_to_lambda(10)
    assert lam**10 == pytest.approx(0.5)


def test_ewma_converges_to_true_variance():
    import random
    random.seed(3)
    e = EwmaVar(halflife_bars=50)
    true_sd = 0.001
    for _ in range(5000):
        e.update(random.gauss(0, true_sd))
    assert e.stdev == pytest.approx(true_sd, rel=0.35)


def test_spot_state_staleness():
    s = SpotState()
    assert s.is_stale(now=1000, max_age_s=3)   # nothing seen yet
    s.on_tick(100_000, 1000)
    assert not s.is_stale(now=1002, max_age_s=3)
    assert s.is_stale(now=1010, max_age_s=3)


def test_spot_state_ignores_out_of_order_ticks():
    s = SpotState()
    s.on_tick(100_000, 1000)
    s.on_tick(99_000, 990)
    assert s.last_price == 100_000


def test_vol_floor_applies():
    s = SpotState(vol_floor_per_sec=1e-4)
    s.on_tick(100_000, 0)
    for i in range(1, 400):
        s.on_tick(100_000, i)   # perfectly flat tape
    assert s.sigma_per_sec() == pytest.approx(1e-4)


def test_vol_ready_requires_history():
    s = SpotState(min_bars=100)
    s.on_tick(100_000, 0)
    for i in range(1, 50):
        s.on_tick(100_000 + i, i)
    assert not s.vol_ready()
    for i in range(50, 200):
        s.on_tick(100_000 + i, i)
    assert s.vol_ready()


def test_long_gap_does_not_explode_vol():
    """A reconnect after a minute must not register as one enormous bar."""
    s = SpotState()
    s.on_tick(100_000, 0)
    for i in range(1, 100):
        s.on_tick(100_000 * math.exp(0.00001 * ((-1) ** i)), i)
    calm = s.sigma_per_sec()
    s.on_tick(100_500, 400)   # 300s gap, 0.5% move
    assert s.sigma_per_sec() < calm * 30


# ---------------------------------------------------------------- risk
class Cfg:
    kill_switch_path = "/tmp/__no_such_kill_file__"
    mode = type("M", (), {"value": "live"})()
    live_armed = True
    spot_max_age_s = 3.0
    book_max_age_s = 5.0
    max_daily_loss_cents = 2000
    min_price_cents = 20
    max_price_cents = 80
    min_seconds_to_expiry = 45
    max_seconds_to_expiry = 780
    max_orders_per_window = 3
    max_contracts_per_window = 5
    max_open_contracts = 20


def intent(**kw):
    base = dict(window_ticker="W", side="yes", price_cents=50,
                contracts=2, seconds_to_expiry=300, is_maker=False)
    base.update(kw)
    return OrderIntent(**base)


def test_risk_allows_a_clean_order():
    g = RiskGate(Cfg())
    d = g.check(intent(), PortfolioState(balance_cents=100_000), 0.5, 0.5, True)
    assert d.allowed and d.reason is Block.OK


def test_risk_blocks_stale_spot():
    g = RiskGate(Cfg())
    d = g.check(intent(), PortfolioState(balance_cents=100_000), 9.0, 0.5, True)
    assert not d.allowed and d.reason is Block.SPOT_STALE


def test_risk_blocks_when_vol_not_ready():
    g = RiskGate(Cfg())
    d = g.check(intent(), PortfolioState(balance_cents=100_000), 0.5, 0.5, False)
    assert d.reason is Block.VOL_NOT_READY


def test_risk_blocks_price_band():
    g = RiskGate(Cfg())
    assert g.check(intent(price_cents=5), PortfolioState(balance_cents=1e6), 0.5, 0.5, True).reason is Block.PRICE_BAND
    assert g.check(intent(price_cents=95), PortfolioState(balance_cents=1e6), 0.5, 0.5, True).reason is Block.PRICE_BAND


def test_risk_blocks_time_band():
    g = RiskGate(Cfg())
    assert g.check(intent(seconds_to_expiry=10), PortfolioState(balance_cents=1e6), .5, .5, True).reason is Block.TIME_BAND
    assert g.check(intent(seconds_to_expiry=880), PortfolioState(balance_cents=1e6), .5, .5, True).reason is Block.TIME_BAND


def test_risk_blocks_daily_loss():
    g = RiskGate(Cfg())
    p = PortfolioState(balance_cents=100_000, realized_pnl_cents_today=-2500)
    assert g.check(intent(), p, 0.5, 0.5, True).reason is Block.DAILY_LOSS_LIMIT


def test_risk_blocks_window_concentration():
    g = RiskGate(Cfg())
    p = PortfolioState(balance_cents=100_000, open_contracts_by_window={"W": 4})
    assert g.check(intent(contracts=3), p, 0.5, 0.5, True).reason is Block.WINDOW_CONTRACT_LIMIT


def test_risk_blocks_insufficient_balance():
    g = RiskGate(Cfg())
    p = PortfolioState(balance_cents=10)
    assert g.check(intent(), p, 0.5, 0.5, True).reason is Block.INSUFFICIENT_BALANCE


def test_kill_switch_beats_everything(tmp_path):
    c = Cfg()
    c.kill_switch_path = str(tmp_path / "KILL")
    open(c.kill_switch_path, "w").close()
    g = RiskGate(c)
    d = g.check(intent(), PortfolioState(balance_cents=1e6), 0.5, 0.5, True)
    assert not d.allowed and d.reason is Block.KILL_SWITCH


def test_shadow_mode_blocks_orders():
    c = Cfg()
    c.live_armed = False
    c.mode = type("M", (), {"value": "shadow"})()
    g = RiskGate(c)
    assert g.check(intent(), PortfolioState(balance_cents=1e6), .5, .5, True).reason is Block.NOT_ARMED


def test_clamp_size_shrinks_rather_than_rejects():
    g = RiskGate(Cfg())
    p = PortfolioState(open_contracts_by_window={"W": 3}, open_contracts_total=3)
    assert g.clamp_size(10, "W", p) == 2


# ---------------------------------------------------------------- strategy
class SCfg:
    fee_coefficient = 0.07
    fee_maker_ratio = 0.25
    min_edge_cents = 3.0
    prefer_maker = False
    kelly_fraction = 0.25
    bankroll_cents = 100_000
    max_contracts_per_window = 5


def test_no_trade_when_market_agrees_with_model():
    book = Book(yes=BookSide(49, 51), no=BookSide(49, 51), ts=0)
    s = evaluate(SCfg(), 100_000, 100_000, 600, 4.8e-5, book)
    assert not s.act


def test_trades_when_yes_is_obviously_cheap():
    # Spot far above strike but yes is quoted at 30c.
    book = Book(yes=BookSide(28, 30), no=BookSide(70, 72), ts=0)
    s = evaluate(SCfg(), 100_400, 100_000, 600, 4.8e-5, book)
    assert s.act and s.side == "yes" and s.contracts > 0


def test_trades_no_side_when_no_is_cheap():
    book = Book(yes=BookSide(70, 72), no=BookSide(28, 30), ts=0)
    s = evaluate(SCfg(), 99_600, 100_000, 600, 4.8e-5, book)
    assert s.act and s.side == "no"


def test_missing_quotes_produce_no_trade():
    book = Book(yes=BookSide(None, None), no=BookSide(None, None), ts=0)
    assert not evaluate(SCfg(), 100_000, 100_000, 600, 4.8e-5, book).act


def test_larger_edge_gives_larger_size():
    small = Book(yes=BookSide(43, 45), no=BookSide(55, 57), ts=0)
    large = Book(yes=BookSide(23, 25), no=BookSide(75, 77), ts=0)
    a = evaluate(SCfg(), 100_400, 100_000, 600, 4.8e-5, small)
    b = evaluate(SCfg(), 100_400, 100_000, 600, 4.8e-5, large)
    assert b.contracts >= a.contracts


def test_size_is_capped():
    book = Book(yes=BookSide(3, 5), no=BookSide(95, 97), ts=0)
    s = evaluate(SCfg(), 101_000, 100_000, 600, 4.8e-5, book)
    assert s.contracts <= SCfg.max_contracts_per_window


def test_degenerate_fair_value_never_trades():
    book = Book(yes=BookSide(40, 42), no=BookSide(58, 60), ts=0)
    s = evaluate(SCfg(), 100_500, 100_000, 0, 4.8e-5, book)
    assert not s.act


def test_maker_preference_improves_the_price():
    c = SCfg()
    c.prefer_maker = True
    book = Book(yes=BookSide(28, 34), no=BookSide(66, 72), ts=0)
    s = evaluate(c, 100_400, 100_000, 600, 4.8e-5, book)
    assert s.act and s.is_maker and s.limit_price_cents == 29


# ---------------------------------------------------------------- signing
def test_signature_is_deterministic_shape_and_verifies():
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import padding, rsa
    from bot.kalshi_client import build_auth_headers, sign_message

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    msg = "1700000000000GET/trade-api/v2/portfolio/balance"
    sig = sign_message(key, msg)

    import base64
    key.public_key().verify(
        base64.b64decode(sig),
        msg.encode(),
        padding.PSS(mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.DIGEST_LENGTH),
        hashes.SHA256(),
    )

    h = build_auth_headers("kid", key, "GET", "/trade-api/v2/portfolio/balance",
                           ts_ms=1700000000000)
    assert h["KALSHI-ACCESS-KEY"] == "kid"
    assert h["KALSHI-ACCESS-TIMESTAMP"] == "1700000000000"
    assert h["KALSHI-ACCESS-SIGNATURE"]


def test_client_order_id_is_stable_and_unique():
    from bot.orders import client_order_id
    a = client_order_id("KXBTC15M-X", "yes", 1)
    assert a == client_order_id("KXBTC15M-X", "yes", 1)   # retry-safe
    assert a != client_order_id("KXBTC15M-X", "yes", 2)
    assert a != client_order_id("KXBTC15M-X", "no", 1)
    assert a != client_order_id("KXBTC15M-Y", "yes", 1)
    assert len(a) == 32


def test_never_emits_an_invalid_limit_price():
    """A side quoted with no bid must not produce a 0c limit."""
    c = SCfg()
    c.prefer_maker = True
    book = Book(yes=BookSide(None, None), no=BookSide(None, 99), ts=0)
    s = evaluate(c, 101_000, 100_000, 600, 4.8e-5, book)
    assert s.limit_price_cents is None or 1 <= s.limit_price_cents <= 99


def test_zero_ask_is_not_a_tradeable_quote():
    book = Book(yes=BookSide(0, 0), no=BookSide(0, 99), ts=0)
    s = evaluate(SCfg(), 101_000, 100_000, 600, 4.8e-5, book)
    assert not s.act
