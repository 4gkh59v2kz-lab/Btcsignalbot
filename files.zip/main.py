#!/usr/bin/env python3
"""Entrypoint.

    python main.py health      check credentials, clock skew, connectivity
    python main.py run         start the engine (shadow unless armed AND gated)
    python main.py gate        print the promotion gate report
    python main.py calibrate   print the reliability table and Brier scores
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import signal
import sys


def load_env(path: str = ".env") -> None:
    if not os.path.exists(path):
        return
    for line in open(path):
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip())


def build(cfg):
    from bot.kalshi_client import KalshiClient, load_private_key
    from bot.store import Store
    from bot.vol import SpotState

    key = None
    if os.path.exists(cfg.private_key_path):
        try:
            key = load_private_key(cfg.private_key_path)
        except Exception as e:
            logging.warning("could not load private key: %s", e)

    client = KalshiClient(
        base_url=cfg.api_base,
        key_id=cfg.api_key_id,
        private_key=key,
        timeout_s=cfg.http_timeout_s,
    )
    store = Store(cfg.db_path)
    spot = SpotState(
        bar_seconds=cfg.vol_bar_seconds,
        fast_halflife_bars=cfg.vol_fast_halflife_bars,
        slow_halflife_bars=cfg.vol_slow_halflife_bars,
        vol_floor_per_sec=cfg.vol_floor_per_sec,
        min_bars=cfg.vol_min_bars,
    )
    return client, store, spot


async def run(cfg) -> None:
    from bot.engine import Engine
    from bot.gate import PromotionGate
    from bot.spot import build_feed

    client, store, spot = build(cfg)

    # The gate is consulted at startup, not just documented. If it fails and
    # the operator asked for live, we downgrade to shadow rather than refuse
    # to run - collecting the data is exactly what will open the gate.
    if cfg.live_armed:
        result = PromotionGate(store).evaluate()
        print(result.report())
        if not result.passed:
            logging.error("promotion gate failed; forcing shadow mode")
            from bot.config import Mode
            object.__setattr__(cfg, "mode", Mode.SHADOW)
            object.__setattr__(cfg, "live_confirm", "")

    feed = build_feed(cfg, spot)
    engine = Engine(cfg, client, store, spot)

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, lambda: (feed.stop(), engine.stop()))
        except NotImplementedError:
            pass

    logging.info("mode=%s armed=%s db=%s", cfg.mode.value, cfg.live_armed, cfg.db_path)
    await asyncio.gather(feed.run(), engine.run())
    store.close()


def cmd_health(cfg) -> int:
    client, store, _ = build(cfg)
    problems = cfg.validate()
    print(f"mode           {cfg.mode.value} (armed={cfg.live_armed})")
    print(f"api base       {cfg.api_base}")
    print(f"key id set     {bool(cfg.api_key_id)}")
    print(f"private key    {'found' if os.path.exists(cfg.private_key_path) else 'MISSING'}")
    print(f"db             {cfg.db_path}")
    try:
        skew = client.check_clock()
        print(f"clock skew     {skew:+.2f}s {'OK' if abs(skew) < 5 else 'TOO LARGE - signing will fail'}")
    except Exception as e:
        print(f"clock skew     could not check: {e}")
    try:
        ms = client.get_markets(cfg.series_ticker)
        print(f"open markets   {len(ms)} in {cfg.series_ticker}")
    except Exception as e:
        print(f"open markets   FAILED: {e}")
    if cfg.live_armed:
        try:
            print(f"balance        {client.get_balance()}")
        except Exception as e:
            print(f"balance        FAILED: {e}")
    for p in problems:
        print(f"PROBLEM: {p}")
    store.close()
    return 1 if problems else 0


def cmd_gate(cfg) -> int:
    from bot.gate import PromotionGate
    _, store, _ = build(cfg)
    result = PromotionGate(store).evaluate()
    print(result.report())
    store.close()
    return 0 if result.passed else 1


def cmd_calibrate(cfg) -> int:
    _, store, _ = build(cfg)
    rows = store.calibration()
    if not rows:
        print("No settled decisions yet. Run in shadow mode and come back.")
        store.close()
        return 1
    print(f"{'bucket':>10}{'n':>7}{'predicted':>12}{'actual':>10}{'gap':>9}")
    for r in rows:
        print(f"{r['bucket']:>10}{r['n']:>7}{r['predicted']:>11.1%}"
              f"{r['actual']:>10.1%}{r['actual']-r['predicted']:>+9.1%}")
    b = store.brier_score()
    print(f"\nBrier score {b:.4f}" if b is not None else "")
    print("Lower is better. The number that matters is this one versus the")
    print("de-vigged market's Brier on the same windows - see `gate`.")
    store.close()
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="KXBTC15M bot")
    ap.add_argument("command", choices=["run", "health", "gate", "calibrate"])
    ap.add_argument("--env", default=".env")
    args = ap.parse_args()

    load_env(args.env)
    from bot.config import Config

    cfg = Config()
    logging.basicConfig(
        level=getattr(logging, cfg.log_level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
    )

    problems = cfg.validate()
    if problems and args.command == "run":
        for p in problems:
            logging.error(p)
        return 1

    if args.command == "health":
        return cmd_health(cfg)
    if args.command == "gate":
        return cmd_gate(cfg)
    if args.command == "calibrate":
        return cmd_calibrate(cfg)

    try:
        asyncio.run(run(cfg))
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
