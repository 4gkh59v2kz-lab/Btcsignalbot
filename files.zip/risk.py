"""The risk gate.

Every intended order passes through check() before it can become a real order.
This is a separate layer from the strategy on purpose: the strategy's job is to
be clever, and clever code is where bugs live. The gate's job is to be dumb,
short, and readable, so that when the clever part malfunctions the damage is
bounded by rules you can read in one sitting.

Checks run in a fixed order and the first failure short-circuits, so the logged
reason is always the most fundamental thing wrong.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from enum import Enum


class Block(str, Enum):
    OK = "ok"
    KILL_SWITCH = "kill_switch"
    NOT_ARMED = "not_armed"
    SPOT_STALE = "spot_stale"
    BOOK_STALE = "book_stale"
    VOL_NOT_READY = "vol_not_ready"
    DAILY_LOSS_LIMIT = "daily_loss_limit"
    WINDOW_CONTRACT_LIMIT = "window_contract_limit"
    OPEN_CONTRACT_LIMIT = "open_contract_limit"
    WINDOW_ORDER_LIMIT = "window_order_limit"
    PRICE_BAND = "price_band"
    TIME_BAND = "time_band"
    BAD_SIZE = "bad_size"
    INSUFFICIENT_BALANCE = "insufficient_balance"


@dataclass(frozen=True)
class Decision:
    allowed: bool
    reason: Block
    detail: str = ""

    def __bool__(self) -> bool:
        return self.allowed


@dataclass
class PortfolioState:
    """What we currently believe we hold. Rebuilt from the exchange on startup
    and after every reconcile - never trusted from local state alone."""

    open_contracts_total: int = 0
    open_contracts_by_window: dict[str, int] = field(default_factory=dict)
    orders_by_window: dict[str, int] = field(default_factory=dict)
    realized_pnl_cents_today: int = 0
    balance_cents: int = 0

    def contracts_in(self, window_ticker: str) -> int:
        return self.open_contracts_by_window.get(window_ticker, 0)

    def orders_in(self, window_ticker: str) -> int:
        return self.orders_by_window.get(window_ticker, 0)


@dataclass(frozen=True)
class OrderIntent:
    window_ticker: str
    side: str          # "yes" or "no"
    price_cents: int   # limit price we would pay
    contracts: int
    seconds_to_expiry: float
    is_maker: bool


class RiskGate:
    def __init__(self, cfg):
        self.cfg = cfg

    # ------------------------------------------------------------------
    def kill_switch_engaged(self) -> bool:
        return os.path.exists(self.cfg.kill_switch_path)

    # ------------------------------------------------------------------
    def check(
        self,
        intent: OrderIntent,
        portfolio: PortfolioState,
        spot_age_s: float,
        book_age_s: float,
        vol_ready: bool,
    ) -> Decision:
        c = self.cfg

        if self.kill_switch_engaged():
            return Decision(False, Block.KILL_SWITCH, f"{c.kill_switch_path} exists")

        if not c.live_armed:
            # Not an error. Shadow mode is the normal state; the engine still
            # logs the intent, it just never reaches the exchange.
            return Decision(False, Block.NOT_ARMED, f"mode={c.mode.value}")

        if spot_age_s > c.spot_max_age_s:
            return Decision(
                False, Block.SPOT_STALE, f"spot {spot_age_s:.1f}s old (max {c.spot_max_age_s})"
            )

        if book_age_s > c.book_max_age_s:
            return Decision(
                False, Block.BOOK_STALE, f"book {book_age_s:.1f}s old (max {c.book_max_age_s})"
            )

        if not vol_ready:
            return Decision(False, Block.VOL_NOT_READY, "insufficient vol history")

        if portfolio.realized_pnl_cents_today <= -abs(c.max_daily_loss_cents):
            return Decision(
                False,
                Block.DAILY_LOSS_LIMIT,
                f"down {abs(portfolio.realized_pnl_cents_today)}c today",
            )

        if intent.contracts <= 0:
            return Decision(False, Block.BAD_SIZE, f"contracts={intent.contracts}")

        if not (c.min_price_cents <= intent.price_cents <= c.max_price_cents):
            return Decision(
                False,
                Block.PRICE_BAND,
                f"{intent.price_cents}c outside [{c.min_price_cents},{c.max_price_cents}]",
            )

        if not (c.min_seconds_to_expiry <= intent.seconds_to_expiry <= c.max_seconds_to_expiry):
            return Decision(
                False,
                Block.TIME_BAND,
                f"{intent.seconds_to_expiry:.0f}s to expiry outside "
                f"[{c.min_seconds_to_expiry:.0f},{c.max_seconds_to_expiry:.0f}]",
            )

        if portfolio.orders_in(intent.window_ticker) >= c.max_orders_per_window:
            return Decision(
                False,
                Block.WINDOW_ORDER_LIMIT,
                f"{portfolio.orders_in(intent.window_ticker)} orders already in this window",
            )

        already = portfolio.contracts_in(intent.window_ticker)
        if already + intent.contracts > c.max_contracts_per_window:
            return Decision(
                False,
                Block.WINDOW_CONTRACT_LIMIT,
                f"{already}+{intent.contracts} > {c.max_contracts_per_window}",
            )

        if portfolio.open_contracts_total + intent.contracts > c.max_open_contracts:
            return Decision(
                False,
                Block.OPEN_CONTRACT_LIMIT,
                f"{portfolio.open_contracts_total}+{intent.contracts} > {c.max_open_contracts}",
            )

        cost = intent.price_cents * intent.contracts
        if portfolio.balance_cents and cost > portfolio.balance_cents:
            return Decision(
                False,
                Block.INSUFFICIENT_BALANCE,
                f"cost {cost}c > balance {portfolio.balance_cents}c",
            )

        return Decision(True, Block.OK)

    # ------------------------------------------------------------------
    def clamp_size(
        self, desired: int, intent_window: str, portfolio: PortfolioState
    ) -> int:
        """Shrink an order to fit remaining headroom instead of rejecting it."""
        c = self.cfg
        room_window = c.max_contracts_per_window - portfolio.contracts_in(intent_window)
        room_total = c.max_open_contracts - portfolio.open_contracts_total
        return max(0, min(desired, room_window, room_total))
