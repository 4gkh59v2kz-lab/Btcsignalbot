# KXBTC15M bot

A server-side trading bot for Kalshi's Bitcoin 15-minute markets: signed API
client, digital-option pricer, EWMA vol estimator, risk gate, idempotent order
manager, SQLite decision log, and a promotion gate that has to open before live
mode is reachable.

**It ships in shadow mode and the gate is currently closed.** That is not
caution for its own sake. It is what your own data says. Read the next section
before anything else.

---

## What your log actually shows

Measured on the 643-window export, of which 337 have recorded ask quotes — the
only ones that can be honestly backtested, because backtesting at the bid or
the mid hands you the spread as profit that does not exist.

**The market is well calibrated.** Grouping your windows by the opening yes
price:

| quoted | n | settled yes |
|---|---|---|
| 0–10c | 15 | 0.0% |
| 30–40c | 43 | 34.9% |
| 40–50c | 56 | 46.4% |
| 50–60c | 76 | 50.0% |
| 70–80c | 31 | 87.1% |
| 90–100c | 19 | 94.7% |

That is close to a fair book. Your median yes-spread is 1c and the overround
(yes_ask + no_ask − 100) is 1c, which is tighter than I assumed — good news for
costs, bad news for the theory that there is obvious mispricing lying around.

**Accuracy above 50% is not edge.** The dashboard flags a stat as proven when
its Wilson interval clears 50%. But buying at price P breaks even at accuracy
P%, not 50%. Against the correct null:

| strategy | n | accuracy | avg entry | breakeven | surplus |
|---|---|---|---|---|---|
| alignedMomentum | 169 | 63.3% | 61.2c | 62.6% | **+0.7pp** |
| antiDivergence | 83 | 66.3% | 62.3c | 63.8% | **+2.5pp** |
| buy the more expensive side | 329 | 68.7% | 67.3c | 68.7% | **−0.0pp** |

"Always buy the favourite" is *more accurate than either strategy* and earns
exactly −0.01c/trade. Both live strategies are favourite-buying with extra
steps. High accuracy is purchasable; it is not evidence.

**Net of fees, at the ask, nothing is significant.**

| strategy | n | c/trade | t | 95% CI |
|---|---|---|---|---|
| alignedMomentum | 169 | +0.69c | +0.20 | [−6.1, +7.4] |
| antiDivergence | 83 | +2.46c | +0.45 | [−8.4, +13.3] |

**Permutation test.** Shuffling outcomes *within price deciles* preserves the
market's calibration and destroys only the signal. Real best-of-six:
+2.46c/trade. Null median: **+2.47c/trade**. p = 0.589. Picking the winner from
six strategies means the bar is the null's 95th percentile (+8.49c), and
nothing comes near it.

(A naive unstratified shuffle is invalid here and I ran that first by mistake —
it produces a null where 70c favourites win 48% of the time, which flatters
every strategy that buys cheap.)

**The paper bankroll is two trades.** 12 trades, 7 wins, +$9.57. The two best
(+$8.90 at 18c, +$3.98 at 32c) contribute 135% of it. The other ten are −$3.31
combined.

**The pricer in this repo loses to the market on your data.** Priced at window
open with a single global sigma: model Brier 0.2299 vs de-vigged market Brier
0.1900. Taking every quote where the model saw edge lost 4.4c/trade, and
raising the threshold to 8c only reduced the bleed to −2.26c — the signature of
a misspecified model, not a mistuned one. Two identified causes: your 15-minute
returns have kurtosis 8.2 (fat tails a Gaussian digital underprices at both
ends), and trailing vol swings 4–15x across the sample so one global sigma is
wrong for most windows. The live EWMA estimator may do better. That is a
hypothesis, not a result.

**You do not have enough data to know.** 337 windows can only detect an edge
above ~10c/trade. Real edges here are 1–3c. Resolving +2c/trade at the observed
per-trade variance (45c) needs about 4,000 trades — roughly 83 days at 50%
firing rate.

### What follows from that

Nothing above proves there is no edge. It proves the sample is about two orders
of magnitude too small to tell, and that the metric the dashboard ranks on
(accuracy vs 50%) will keep producing confident-looking results that mean
nothing. The measured config defaults in `config.example.env` come from this
analysis. Re-run it any time with `research/analyze*.py`.

---

## Layout

```
bot/config.py         settings; every default that came from your data says so
bot/fees.py           taker/maker fee model
bot/pricer.py         Black-Scholes digital + implied-vol inversion
bot/vol.py            two-speed EWMA vol, staleness tracking
bot/strategy.py       edge vs quote, fractional Kelly sizing
bot/risk.py           the risk gate — read this one
bot/gate.py           promotion gate; guards live mode
bot/kalshi_client.py  RSA-PSS signed REST client
bot/spot.py           Coinbase websocket feed (+ polling fallback)
bot/orders.py         idempotent placement, exchange reconciliation
bot/store.py          SQLite: decisions, orders, fills, settlements, equity
bot/engine.py         the loop
main.py               run | health | gate | calibrate
research/             the analysis scripts behind the numbers above
```

## Running it

```bash
pip install -r requirements.txt
cp config.example.env .env        # fill in key id + key path
python main.py health             # credentials, clock skew, connectivity
python main.py run                # shadow mode
```

Then leave it. In shadow mode it prices every open window every second and
writes every evaluation to the `decisions` table without sending anything.
After a few weeks:

```bash
python main.py calibrate          # reliability table + Brier
python main.py gate               # can this go live yet?
```

## The gate

Live mode needs `MODE=live` **and** `LIVE_CONFIRM=yes-real-money` **and** a
passing gate. `main.py run` downgrades to shadow if the gate fails. Current
requirements (in `bot/gate.py`, edit in daylight with a reason):

- 4,000 logged decisions, 2,000 settled
- model Brier ≤ de-vigged market Brier on the same windows
- ≥5 well-calibrated price buckets (n≥30, predicted inside the Wilson CI)
- realised paper edge ≥1c/trade with t ≥ 2.0

## Things that will bite

- **Settlement source.** Kalshi settles BTC markets against a specific
  reference. `SPOT_SOURCE` defaults to Coinbase because I don't know which one
  it is. Confirm it in the series rules — trading off the wrong feed prices a
  different contract than the one you're buying, and it matters most in the
  last minute, which is the minute that decides everything.
- **Fees.** Sources disagree on the crypto coefficient and on maker treatment
  (25% of taker vs free). Measure your own fills and set `FEE_COEFFICIENT` /
  `FEE_MAKER_RATIO` from data. If maker really is free, this should quote and
  wait far more aggressively than it currently does.
- **Base URL.** It has moved before. Verify against docs.kalshi.com.
- **Clock skew.** Signatures carry a timestamp. A drifting container clock
  produces 401s that look like a key problem. `health` checks it.
- **`touch KILL`** halts all new orders without stopping the process.

## Tests

```bash
pytest tests/ -q     # 44 tests, no network required
```

They cover the fee curve, pricer boundaries and monotonicity, implied-vol
roundtrip, EWMA convergence, gap handling, every risk-gate branch, sizing caps,
invalid-price guards, RSA-PSS signature verification, and order-id idempotency.

---

Not financial advice. Nothing here is a recommendation to trade, and the
analysis above is a reason to be slower rather than faster.
