"""The main loop.

Each cycle: refresh the open windows, pull each book, price it, evaluate,
gate it, and either send or log why not. Every evaluation is written to the
decisions table whether or not it becomes an order - that table is the whole
point of running this in shadow mode, because it is what the calibration and
power analysis are computed from later.
"""

from __future__ import annotations

import asyncio
import logging
import time
from datetime import datetime, timezone

from .kalshi_client import KalshiClient, KalshiError
from .orders import OrderManager
from .risk import Block, OrderIntent, PortfolioState, RiskGate
from .strategy import Book, BookSide, evaluate
from .vol import SpotState

log = logging.getLogger(__name__)


def parse_expiry(market: dict) -> float | None:
    """Unix seconds of settlement, from whichever field the API supplies."""
    for key in ("close_time", "expiration_time", "latest_expiration_time"):
        v = market.get(key)
        if not v:
            continue
        try:
            return datetime.fromisoformat(str(v).replace("Z", "+00:00")).timestamp()
        except ValueError:
            continue
    return None


def parse_strike(market: dict) -> float | None:
    """KXBTC15M markets carry the level in a strike field, not in the ticker
    suffix - the suffix is the window's minute mark."""
    for key in ("floor_strike", "strike_price", "cap_strike", "settlement_value"):
        v = market.get(key)
        if v not in (None, ""):
            try:
                return float(v)
            except (TypeError, ValueError):
                continue
    return None


def book_from_market(market: dict, ts: float) -> Book:
    """Best bid/ask per side.

    Kalshi quotes both sides; `no_bid` is derivable as 100 - yes_ask but the
    API gives it directly, so use what it gives rather than deriving and
    quietly inventing liquidity that isn't there.
    """
    def _i(v):
        try:
            return int(v) if v not in (None, "", 0) else None
        except (TypeError, ValueError):
            return None

    return Book(
        yes=BookSide(bid=_i(market.get("yes_bid")), ask=_i(market.get("yes_ask"))),
        no=BookSide(bid=_i(market.get("no_bid")), ask=_i(market.get("no_ask"))),
        ts=ts,
    )


class Engine:
    def __init__(self, cfg, client: KalshiClient, store, spot: SpotState):
        self.cfg = cfg
        self.client = client
        self.store = store
        self.spot = spot
        self.gate = RiskGate(cfg)
        self.orders = OrderManager(client, store, cfg) if client else None
        self.portfolio = PortfolioState()
        self._last_reconcile = 0.0
        self._book_ts: dict[str, float] = {}
        self._traded_windows: set[str] = set()
        self._stop = asyncio.Event()

    def stop(self) -> None:
        self._stop.set()

    # ------------------------------------------------------------------
    async def run(self) -> None:
        log.info("engine starting in %s mode (armed=%s)",
                 self.cfg.mode.value, self.cfg.live_armed)
        if self.cfg.live_armed and self.orders:
            self.portfolio = await asyncio.to_thread(self.orders.reconcile)

        while not self._stop.is_set():
            try:
                await self.cycle()
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("cycle failed; continuing")
            await asyncio.sleep(self.cfg.book_poll_interval_s)

    # ------------------------------------------------------------------
    async def cycle(self) -> None:
        now = time.time()

        if self.cfg.live_armed and self.orders and now - self._last_reconcile > 60:
            self.portfolio = await asyncio.to_thread(self.orders.reconcile)
            self._last_reconcile = now
            self.store.record_equity(
                self.portfolio.balance_cents,
                self.portfolio.open_contracts_total,
                self.portfolio.realized_pnl_cents_today,
            )

        try:
            markets = await asyncio.to_thread(
                self.client.get_markets, self.cfg.series_ticker, "open", 100
            )
        except KalshiError as e:
            log.warning("market list failed: %s", e)
            return

        for m in markets:
            self.consider(m, now)

    # ------------------------------------------------------------------
    def consider(self, market: dict, now: float) -> None:
        ticker = market.get("ticker")
        if not ticker:
            return

        expiry = parse_expiry(market)
        strike = parse_strike(market)
        if expiry is None or strike is None:
            return

        seconds_left = expiry - now
        if seconds_left <= 0:
            return

        book = book_from_market(market, now)
        self._book_ts[ticker] = now

        spot_price = self.spot.last_price
        if spot_price is None:
            return

        sigma = self.spot.sigma_per_sec()
        signal = evaluate(
            self.cfg, spot_price, strike, seconds_left, sigma, book
        )

        blocked_by: str | None = None
        if signal.act:
            contracts = self.gate.clamp_size(
                signal.contracts, ticker, self.portfolio
            )
            intent = OrderIntent(
                window_ticker=ticker,
                side=signal.side,
                price_cents=signal.limit_price_cents,
                contracts=contracts,
                seconds_to_expiry=seconds_left,
                is_maker=signal.is_maker,
            )
            decision = self.gate.check(
                intent,
                self.portfolio,
                spot_age_s=self.spot.age(now),
                book_age_s=0.0,
                vol_ready=self.spot.vol_ready(),
            )
            if not decision.allowed:
                blocked_by = decision.reason.value
                if decision.reason is not Block.NOT_ARMED:
                    log.info("blocked %s: %s (%s)", ticker, blocked_by, decision.detail)
            else:
                result = self.orders.place(intent)
                if result.sent:
                    self.portfolio.open_contracts_total += contracts
                    self.portfolio.open_contracts_by_window[ticker] = (
                        self.portfolio.contracts_in(ticker) + contracts
                    )
                    self.portfolio.orders_by_window[ticker] = (
                        self.portfolio.orders_in(ticker) + 1
                    )
                else:
                    blocked_by = "send_failed"

        self.store.record_decision(
            window_ticker=ticker,
            strike=strike,
            spot=spot_price,
            seconds_left=seconds_left,
            sigma_per_sec=sigma,
            signal=signal,
            book=book,
            blocked_by=blocked_by,
        )
