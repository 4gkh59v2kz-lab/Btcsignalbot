"""Turning a fair value into an order intent.

The rule is simple and deliberately so: buy the side whose net-of-fee cost is
below what we think it is worth, by more than a margin that covers model error.

    edge_yes = fair_yes_cents - (yes_ask + fee_per_contract + margin)
    edge_no  = fair_no_cents  - (no_ask  + fee_per_contract + margin)

We never buy both sides and we never sell (Kalshi's "sell yes" is economically
"buy no", so the no-side branch already covers it).

Sizing is fractional Kelly on the net-of-fee price. Full Kelly assumes your
probability estimate is correct, which yours is not - it comes from a vol
estimate with real error bars. A quarter Kelly costs you a quarter of the
growth rate and buys a large reduction in the chance of a drawdown that ends
the experiment.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from .fees import fee_per_contract_cents
from .pricer import FairValue, digital_fair_value, implied_sigma_per_sec


@dataclass(frozen=True)
class BookSide:
    """Best prices for one side of a Kalshi market, in cents."""
    bid: int | None
    ask: int | None


@dataclass(frozen=True)
class Book:
    yes: BookSide
    no: BookSide
    ts: float

    @property
    def yes_spread(self) -> int | None:
        if self.yes.bid is None or self.yes.ask is None:
            return None
        return self.yes.ask - self.yes.bid


@dataclass(frozen=True)
class Signal:
    act: bool
    side: str | None            # "yes" | "no"
    limit_price_cents: int | None
    contracts: int
    edge_cents: float
    fair: FairValue
    is_maker: bool
    implied_sigma: float | None
    reason: str


def _kelly_contracts(
    prob_win: float,
    net_price_cents: float,
    bankroll_cents: int,
    fraction: float,
) -> int:
    """Fractional Kelly for a binary paying 100c on a net_price_cents stake.

    f* = (q - p) / (1 - p) with p the effective probability we are paying.
    Stake = f* * bankroll; contracts = stake / cost_per_contract.
    """
    p = net_price_cents / 100.0
    if not 0.0 < p < 1.0:
        return 0
    q = min(max(prob_win, 0.0), 1.0)
    edge = q - p
    if edge <= 0:
        return 0
    f_star = edge / (1.0 - p)
    stake_cents = f_star * fraction * bankroll_cents
    return int(math.floor(stake_cents / net_price_cents))


def evaluate(
    cfg,
    spot: float,
    strike: float,
    seconds_to_expiry: float,
    sigma_per_sec: float,
    book: Book,
) -> Signal:
    fair = digital_fair_value(spot, strike, seconds_to_expiry, sigma_per_sec)

    # Diagnostic only, but worth logging: it tells you whether you disagree
    # with the market about volatility or about the price of bitcoin.
    mid_yes = None
    if book.yes.bid is not None and book.yes.ask is not None:
        mid_yes = (book.yes.bid + book.yes.ask) / 2.0
    implied = (
        implied_sigma_per_sec(mid_yes, spot, strike, seconds_to_expiry)
        if mid_yes is not None
        else None
    )

    no_signal = lambda reason: Signal(
        act=False, side=None, limit_price_cents=None, contracts=0,
        edge_cents=0.0, fair=fair, is_maker=False, implied_sigma=implied,
        reason=reason,
    )

    if fair.degenerate:
        return no_signal("degenerate fair value (no time or no vol)")

    candidates: list[tuple[float, str, int, bool]] = []  # (edge, side, limit, is_maker)

    def valid_price(px: int | None) -> bool:
        # Kalshi prices are integers 1..99. A limit of 0 or 100 is not an
        # order, it is a bug, and the risk gate should not be the first thing
        # that notices.
        return px is not None and 1 <= px <= 99

    for side, side_book, fair_cents in (
        ("yes", book.yes, fair.yes_cents),
        ("no", book.no, fair.no_cents),
    ):
        # Taker: cross the spread and pay the ask.
        if valid_price(side_book.ask):
            fee = fee_per_contract_cents(
                side_book.ask, False, cfg.fee_coefficient, cfg.fee_maker_ratio
            )
            edge = fair_cents - (side_book.ask + fee + cfg.min_edge_cents)
            candidates.append((edge, side, side_book.ask, False))

        # Maker: join or improve the bid and wait. Cheaper fee and a better
        # price, at the cost of an uncertain fill. Only worth quoting if the
        # improved price still leaves edge.
        if cfg.prefer_maker and valid_price(side_book.bid):
            limit = side_book.bid + 1 if (
                side_book.ask is None or side_book.bid + 1 < side_book.ask
            ) else side_book.bid
            if not valid_price(limit):
                continue
            fee = fee_per_contract_cents(
                limit, True, cfg.fee_coefficient, cfg.fee_maker_ratio
            )
            edge = fair_cents - (limit + fee + cfg.min_edge_cents)
            candidates.append((edge, side, limit, True))

    if not candidates:
        return no_signal("no quotes on either side")

    edge, side, limit, is_maker = max(candidates, key=lambda c: c[0])

    if not valid_price(limit):
        return no_signal(f"computed limit {limit} outside 1..99")

    if edge <= 0:
        return Signal(
            act=False, side=None, limit_price_cents=None, contracts=0,
            edge_cents=edge, fair=fair, is_maker=False, implied_sigma=implied,
            reason=f"best edge {edge:.2f}c below threshold",
        )

    prob = fair.prob_yes if side == "yes" else (1.0 - fair.prob_yes)
    fee = fee_per_contract_cents(limit, is_maker, cfg.fee_coefficient, cfg.fee_maker_ratio)
    contracts = _kelly_contracts(prob, limit + fee, cfg.bankroll_cents, cfg.kelly_fraction)
    contracts = min(contracts, cfg.max_contracts_per_window)

    if contracts <= 0:
        return Signal(
            act=False, side=side, limit_price_cents=limit, contracts=0,
            edge_cents=edge, fair=fair, is_maker=is_maker, implied_sigma=implied,
            reason="kelly size rounded to zero",
        )

    return Signal(
        act=True, side=side, limit_price_cents=limit, contracts=contracts,
        edge_cents=edge, fair=fair, is_maker=is_maker, implied_sigma=implied,
        reason=f"edge {edge:.2f}c on {side} at {limit}c",
    )
