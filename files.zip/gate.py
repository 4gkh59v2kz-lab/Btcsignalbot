"""The promotion gate.

Everything else in this package is machinery for placing orders. This module is
the thing that decides whether the machinery has earned the right to place
them, and it exists because of what your own log says.

Measured on 337 KXBTC15M windows with recorded ask quotes:

  - The market is well calibrated. Contracts quoted 40-50c settled yes 46% of
    the time; 70-80c settled yes 87%; 90-100c settled yes 95%. It is not
    leaving obvious money on the table.
  - alignedMomentum was 63.3% accurate, but its average entry was 61.2c, where
    breakeven accuracy is 62.6%. Net: +0.69c/trade, standard error 3.45c.
  - "Buy whichever side is more expensive" was 68.7% accurate - better than
    either real strategy - and earned exactly -0.01c/trade. Accuracy above 50%
    is purchasable by buying favourites; it is not evidence of anything.
  - A permutation test that shuffles outcomes WITHIN price deciles (preserving
    the market's calibration, destroying only the signal) puts the real
    best-of-six at +2.46c/trade against a null median of +2.47c. p = 0.589.
  - 337 windows can only detect an edge above roughly 10c/trade. Real edges in
    these markets are 1-3c. Resolving a +2c edge needs about 4,000 trades.

So: nothing is proven, nothing is disproven, and the sample is roughly two
orders of magnitude too small to tell. The gate below encodes that as code
rather than as a note you'll talk yourself out of at 2am.
"""

from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass(frozen=True)
class GateResult:
    passed: bool
    checks: dict[str, tuple[bool, str]]

    def report(self) -> str:
        lines = []
        for name, (ok, detail) in self.checks.items():
            lines.append(f"  [{'PASS' if ok else 'FAIL'}] {name}: {detail}")
        verdict = "GATE OPEN - live trading permitted" if self.passed else \
                  "GATE CLOSED - shadow mode only"
        return "\n".join(lines) + f"\n{verdict}"


def wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n == 0:
        return (0.0, 1.0)
    p = k/n
    den = 1 + z*z/n
    c = (p + z*z/(2*n))/den
    h = z*math.sqrt(p*(1-p)/n + z*z/(4*n*n))/den
    return (c-h, c+h)


class PromotionGate:
    """Requirements the shadow record must meet before live mode is allowed.

    Deliberately strict. Loosen these only by editing this file, in daylight,
    with a reason you'd defend to someone else.
    """

    MIN_DECISIONS = 4000          # from the power analysis, not from taste
    MIN_SETTLED = 2000
    MAX_BRIER_VS_MARKET = 1.0     # model Brier must be <= market Brier
    MIN_CALIBRATION_BUCKETS = 5   # buckets with n>=30 that contain their CI
    MIN_EDGE_CENTS_PER_TRADE = 1.0
    MIN_T_STAT = 2.0

    def __init__(self, store):
        self.store = store

    # ------------------------------------------------------------------
    def evaluate(self) -> GateResult:
        checks: dict[str, tuple[bool, str]] = {}
        c = self.store.conn

        n_dec = c.execute("SELECT COUNT(*) n FROM decisions").fetchone()["n"]
        checks["sample size"] = (
            n_dec >= self.MIN_DECISIONS,
            f"{n_dec} decisions logged, need {self.MIN_DECISIONS}",
        )

        rows = c.execute(
            """SELECT d.fair_yes_cents p, d.yes_ask, d.no_ask, s.result
               FROM decisions d JOIN settlements s USING (window_ticker)
               WHERE s.result IS NOT NULL"""
        ).fetchall()
        checks["settled outcomes"] = (
            len(rows) >= self.MIN_SETTLED,
            f"{len(rows)} settled, need {self.MIN_SETTLED}",
        )

        if not rows:
            checks["calibration"] = (False, "no settled outcomes yet")
            checks["beats market"] = (False, "no settled outcomes yet")
            checks["realised edge"] = (False, "no settled outcomes yet")
            return GateResult(False, checks)

        # --- model vs de-vigged market, by Brier score ---
        mb = model_b = 0.0
        mn = 0
        for r in rows:
            outcome = 1.0 if str(r["result"]).lower() == "yes" else 0.0
            model_b += (r["p"]/100.0 - outcome) ** 2
            if r["yes_ask"] and r["no_ask"]:
                tot = r["yes_ask"] + r["no_ask"]
                if tot > 0:
                    mb += (r["yes_ask"]/tot - outcome) ** 2
                    mn += 1
        model_b /= len(rows)
        market_b = mb/mn if mn else None
        if market_b is None:
            checks["beats market"] = (False, "no market quotes recorded")
        else:
            ratio = model_b/market_b
            checks["beats market"] = (
                ratio <= self.MAX_BRIER_VS_MARKET,
                f"model Brier {model_b:.4f} vs market {market_b:.4f} "
                f"(ratio {ratio:.3f}, need <= {self.MAX_BRIER_VS_MARKET})",
            )

        # --- reliability: does each bucket's actual land inside its CI? ---
        good = 0
        for b in range(10):
            lo, hi = b*10, (b+1)*10
            sel = [r for r in rows if lo <= r["p"] < hi]
            if len(sel) < 30:
                continue
            k = sum(1 for r in sel if str(r["result"]).lower() == "yes")
            clo, chi = wilson(k, len(sel))
            pred = sum(r["p"] for r in sel)/len(sel)/100
            if clo <= pred <= chi:
                good += 1
        checks["calibration"] = (
            good >= self.MIN_CALIBRATION_BUCKETS,
            f"{good} well-calibrated buckets (n>=30), need {self.MIN_CALIBRATION_BUCKETS}",
        )

        # --- realised paper edge on decisions that would have been acted on ---
        acted = c.execute(
            """SELECT d.limit_cents px, d.side, s.result
               FROM decisions d JOIN settlements s USING (window_ticker)
               WHERE d.acted = 1 AND d.limit_cents IS NOT NULL
                 AND s.result IS NOT NULL"""
        ).fetchall()
        if len(acted) < 30:
            checks["realised edge"] = (False, f"only {len(acted)} actionable trades")
        else:
            pnls = []
            for r in acted:
                px = r["px"]
                f = 0.07 * (px/100) * (1-px/100) * 100
                won = str(r["result"]).lower() == str(r["side"]).lower()
                pnls.append((100-px-f) if won else (-px-f))
            n = len(pnls)
            mean = sum(pnls)/n
            var = sum((x-mean)**2 for x in pnls)/n
            se = math.sqrt(var/n) if var > 0 else 0.0
            t = mean/se if se else 0.0
            checks["realised edge"] = (
                mean >= self.MIN_EDGE_CENTS_PER_TRADE and t >= self.MIN_T_STAT,
                f"{mean:+.2f}c/trade over {n} trades, t={t:+.2f} "
                f"(need >= {self.MIN_EDGE_CENTS_PER_TRADE}c and t >= {self.MIN_T_STAT})",
            )

        passed = all(ok for ok, _ in checks.values())
        return GateResult(passed, checks)
