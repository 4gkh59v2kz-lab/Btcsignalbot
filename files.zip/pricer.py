"""Fair value for a binary "will BTC settle above K" contract.

Over a 15 minute horizon BTC is close to a driftless diffusion, so the
risk-neutral probability of finishing above the strike is the Black-Scholes
digital:

    sigma_tau = sigma_per_sec * sqrt(seconds_remaining)
    d2        = (ln(S/K) - 0.5 * sigma_tau^2) / sigma_tau
    P(S_T > K) = Phi(d2)

The drift term is set to zero. Over 900 seconds any realistic drift is swamped
by the diffusion, and estimating it from recent returns is how momentum
strategies quietly turn into noise fitting.

The -0.5*sigma_tau^2 term is small here but kept so the pricer stays correct if
anyone points it at a longer horizon.

Everything is expressed in *cents* on the way out because that is what the
order book speaks.
"""

from __future__ import annotations

import math
from dataclasses import dataclass


def norm_cdf(x: float) -> float:
    """Standard normal CDF via erf. Accurate enough; no scipy dependency."""
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


@dataclass(frozen=True)
class FairValue:
    prob_yes: float          # 0..1
    yes_cents: float         # 0..100
    no_cents: float          # 0..100
    sigma_tau: float         # stdev of log return over remaining life
    d2: float
    degenerate: bool = False  # True when time or vol collapsed to ~0


def digital_fair_value(
    spot: float,
    strike: float,
    seconds_remaining: float,
    sigma_per_sec: float,
) -> FairValue:
    """Probability that spot finishes strictly above strike.

    Args:
        spot: current underlying price.
        strike: contract strike.
        seconds_remaining: time to settlement, in seconds.
        sigma_per_sec: per-second stdev of log returns (NOT annualised).
    """
    if spot <= 0 or strike <= 0:
        raise ValueError("spot and strike must be positive")
    if sigma_per_sec < 0:
        raise ValueError("sigma_per_sec must be non-negative")

    seconds_remaining = max(seconds_remaining, 0.0)
    sigma_tau = sigma_per_sec * math.sqrt(seconds_remaining)

    # At expiry, or with no volatility, the contract is already decided.
    if sigma_tau <= 1e-12:
        p = 1.0 if spot > strike else 0.0
        return FairValue(
            prob_yes=p,
            yes_cents=p * 100.0,
            no_cents=(1.0 - p) * 100.0,
            sigma_tau=sigma_tau,
            d2=math.inf if spot > strike else -math.inf,
            degenerate=True,
        )

    d2 = (math.log(spot / strike) - 0.5 * sigma_tau * sigma_tau) / sigma_tau
    p = norm_cdf(d2)
    return FairValue(
        prob_yes=p,
        yes_cents=p * 100.0,
        no_cents=(1.0 - p) * 100.0,
        sigma_tau=sigma_tau,
        d2=d2,
    )


def implied_sigma_per_sec(
    market_yes_cents: float,
    spot: float,
    strike: float,
    seconds_remaining: float,
    lo: float = 1e-7,
    hi: float = 1e-2,
    tol: float = 1e-10,
) -> float | None:
    """Back out the per-second vol the market quote implies, by bisection.

    Useful for diagnostics: comparing implied vol against your realised vol
    estimate tells you *why* you think a quote is wrong, which is a much better
    logged reason than "the signal fired".

    Returns None when the quote is not invertible (deep in/out of the money at
    any vol, or seconds_remaining is zero).
    """
    if seconds_remaining <= 0 or spot <= 0 or strike <= 0:
        return None
    target = market_yes_cents / 100.0
    if not 0.0 < target < 1.0:
        return None

    def f(sig: float) -> float:
        return digital_fair_value(spot, strike, seconds_remaining, sig).prob_yes - target

    f_lo, f_hi = f(lo), f(hi)
    if f_lo * f_hi > 0:
        # Not bracketed. Happens when the quote is outside what any vol produces.
        return None

    for _ in range(200):
        mid = 0.5 * (lo + hi)
        f_mid = f(mid)
        if abs(f_mid) < tol:
            return mid
        if f_lo * f_mid <= 0:
            hi, f_hi = mid, f_mid
        else:
            lo, f_lo = mid, f_mid
    return 0.5 * (lo + hi)
