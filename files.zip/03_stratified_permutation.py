"""Stratified permutation test.

The naive shuffle was wrong: it destroyed P(win | price), so the null world was
one where a 70c favourite wins 48% of the time. Every strategy that buys cheap
looked brilliant there.

The correct null keeps the market honest and only destroys the strategy's
claimed extra information: shuffle outcomes WITHIN price buckets. Then
P(win | price) is preserved exactly, and the only thing broken is any link
between the signal and the outcome.
"""
import json, math, random, collections, statistics as st

D = json.load(open('/mnt/user-data/uploads/kxbtc15m_backup_2026-09-10.json'))
W = list(D['windows'].values())
obs = [x for x in W if x.get('result') in ('yes', 'no')]
pool = [x for x in obs if x.get('firstYesAsk') and x.get('firstNoAsk')]
pool.sort(key=lambda x: x.get('closeTime') or '')


def fee(px, coef=0.07):
    p = px/100
    return coef*p*(1-p)*100


def mom(x):
    m1, m5 = x.get('firstMom1m'), x.get('firstMom5m')
    if m1 is None or m5 is None: return None
    if m1 > 0 and m5 > 0: return 'yes'
    if m1 < 0 and m5 < 0: return 'no'
    return None


def antidiv(x):
    if not x.get('divergenceSeen'): return None
    dd = x.get('divergenceDirection')
    if dd is None: return None
    return 'no' if str(dd).lower() in ('up','yes','bullish') else 'yes'


STRATS = {
    "alignedMomentum": mom,
    "antiDivergence": antidiv,
    "favourite": lambda x: 'yes' if x['firstYesAsk'] > x['firstNoAsk'] else 'no',
    "underdog": lambda x: 'no' if x['firstYesAsk'] > x['firstNoAsk'] else 'yes',
    "alwaysYes": lambda x: 'yes',
    "alwaysNo": lambda x: 'no',
}


def mean_pnl(fn, data):
    tot = n = 0
    for x in data:
        s = fn(x)
        if s is None: continue
        px = x['firstYesAsk'] if s == 'yes' else x['firstNoAsk']
        if not px or not (1 <= px <= 99): continue
        won = x['result'] == s
        tot += (100-px-fee(px)) if won else (-px-fee(px))
        n += 1
    return (tot/n, n) if n else (None, 0)


# ---- strata on the yes price, which is what carries the calibration ----
def bucket(x):
    return min(9, int(x['firstYesAsk']/10))


strata = collections.defaultdict(list)
for i, x in enumerate(pool):
    strata[bucket(x)].append(i)

print("="*72)
print("STRATIFIED PERMUTATION TEST (2000 shuffles within yes-price deciles)")
print("="*72)
print(f"{'stratum':>10}{'n':>6}{'P(yes)':>9}")
for b in sorted(strata):
    idx = strata[b]
    k = sum(1 for i in idx if pool[i]['result'] == 'yes')
    print(f"{b*10:>7}-{b*10+10:<3}{len(idx):>6}{k/len(idx):>9.1%}")
print("\nThese conditional rates are preserved by every shuffle below.\n")

random.seed(11)
real = {name: mean_pnl(fn, pool) for name, fn in STRATS.items()}
real_best = max(v[0] for v in real.values() if v[0] is not None)

null_each = collections.defaultdict(list)
null_best = []
outcomes = [x['result'] for x in pool]

for _ in range(2000):
    shuffled = outcomes[:]
    for idx in strata.values():
        vals = [shuffled[i] for i in idx]
        random.shuffle(vals)
        for i, v in zip(idx, vals):
            shuffled[i] = v
    fake = [dict(x, result=r) for x, r in zip(pool, shuffled)]
    bests = []
    for name, fn in STRATS.items():
        m, n = mean_pnl(fn, fake)
        if m is not None:
            null_each[name].append(m)
            bests.append(m)
    null_best.append(max(bests))

print(f"{'strategy':<18}{'n':>5}{'real c/tr':>11}{'null mean':>11}{'null p95':>10}{'p-value':>9}")
for name in STRATS:
    m, n = real[name]
    if m is None: continue
    dist = sorted(null_each[name])
    p = sum(1 for d in dist if d >= m)/len(dist)
    print(f"{name:<18}{n:>5}{m:>+10.2f}c{st.mean(dist):>+10.2f}c"
          f"{dist[int(.95*len(dist))]:>+9.2f}c{p:>9.3f}")

nb = sorted(null_best)
p_best = sum(1 for d in nb if d >= real_best)/len(nb)
print()
print(f"best-of-six, real          {real_best:+.2f}c/trade")
print(f"best-of-six, null median   {nb[len(nb)//2]:+.2f}c/trade")
print(f"best-of-six, null 95th pct {nb[int(.95*len(nb))]:+.2f}c/trade")
print(f"best-of-six p-value        {p_best:.3f}"
      f"   {'NOT significant' if p_best > 0.05 else 'significant'}")
print()
print("Read that bottom line carefully: picking the winner from six strategies")
print("means the bar is the null's 95th percentile, not zero. The best strategy")
print("has to clear that bar, and it does not.")

print()
print("="*72)
print("HOW BIG AN EDGE COULD STILL BE HIDING IN 337 WINDOWS?")
print("="*72)
print("The test above cannot distinguish 'no edge' from 'a small edge'.")
print("Power analysis on what you have:\n")
for n, label in ((169, "alignedMomentum (169 trades)"), (83, "antiDivergence (83 trades)")):
    sd = 45.0  # observed per-trade stdev in cents
    mde = (1.96 + 0.84) * sd / math.sqrt(n)
    print(f"  {label:<32} can only detect an edge above {mde:+.1f}c/trade")
print(f"\n  For reference, a genuinely good edge in these markets is 1-3c/trade.")
print("  Detecting +2c/trade at this variance needs:")
for target in (1.0, 2.0, 3.0):
    n_req = ((1.96+0.84)*45.0/target)**2
    print(f"    {target:.0f}c/trade -> {n_req:,.0f} trades")
print("\n  At 96 windows/day, a strategy firing on 50% of them takes")
print(f"    {((1.96+0.84)*45.0/2.0)**2/48:,.0f} days to resolve a +2c edge.")
